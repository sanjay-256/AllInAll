// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import productData from "../assects/product.json";
// import Csmallcard from "./Csmallcard"; 
// import { useNavigate } from "react-router-dom";

// const Wishlist = () => {
//     const navigate = useNavigate(); 
//   const [wishlistProducts, setWishlistProducts] = useState(productData);
//   const [loading, setLoading] = useState(false);

// const handleProductSelect = (product) => {
//     navigate(`/displaycard/${product.id}`);
//   };

//   return (
//     <div className="min-h-screen bg-gray-100">
//       <div className="container mx-auto py-10">
//         <h1 className="text-2xl font-bold text-center mb-6">Your Wishlist</h1>
//         {loading ? (
//           <p className="text-center text-gray-500">Loading wishlist...</p>
//         ) : wishlistProducts.length > 0 ? (
//           <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
//             {wishlistProducts.map((product) => (
//               <Csmallcard
//                 key={product.id}
//                 product={product}
//                 classname="bg-white shadow-lg rounded-md"
//                 onClick={() => handleProductSelect(product)}
//               />
//             ))}
//           </div>
//         ) : (
//           <p className="text-center text-gray-500">Your wishlist is empty.</p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Wishlist;




// code with backend

import React, { useEffect, useState } from "react";
import axios from "axios";
import Csmallcard from "./Csmallcard"; 

const Wishlist = () => {
  const [wishlistProducts, setWishlistProducts] = useState([]);
  const [loading, setLoading] = useState(true);


  useEffect(() => {
    const fetchWishlist = async () => {
      try {
        const email = localStorage.getItem("useremail");
        const user = await axios.get(`http://localhost:8080/user/getuserid/${email}`);
        const userid = user.data;

        const response = await axios.get(`http://localhost:8080/wishlist/getproducts/${userid}`);
        setWishlistProducts(response.data || []);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching wishlist:", error);
        setLoading(false);
      }
    };

    fetchWishlist();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto py-10">
        <h1 className="text-2xl font-bold text-center mb-6">Your Wishlist</h1>
        {loading ? (
          <p className="text-center text-gray-500">Loading wishlist...</p>
        ) : wishlistProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {wishlistProducts.map((product) => (
              <Csmallcard
                key={product.id}
                product={product}
                classname="bg-white shadow-lg rounded-md"
              />
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500">Your wishlist is empty.</p>
        )}
      </div>
    </div>
  );
};

export default Wishlist;
