import React from 'react'
import "../App.css"

const About = () => {
  return (
    <div>
      <div className="p-5">
        <div className="text-center mx-auto lg:w-4/6">
          <div className="1 my-10">
            <div className="brand font-semibold text-3xl md:text-4xl">- All In All -</div>
            <p className="ahead text-xl md:text-2xl font-medium">
            "Welcome to All in All! Our shop is your one-stop destination for stylish and quality attire for everyone—men, women, and kids. Whether you're dressing up for a wedding, preparing for a casual day out, or shopping for a special occasion, we have something perfect just for you."
            </p>
          </div>
          <div className="2 my-10">
            <div className="atext1 pb-5 text-3xl md:text-4xl text-right md:pr-10">Inclusivity in Fashion</div>
            <p className="ahead text-xl md:text-2xl font-medium">
              "Welcome to All in All! Our shop is your one-stop destination for stylish and quality attire for everyone—men, women, and kids. Whether you're dressing up for a wedding, preparing for a casual day out, or shopping for a special occasion, we have something perfect just for you."
              </p>
          </div>
          <div className="3 my-10">
            <div className="atext1 pb-5 text-3xl md:text-4xl text-left md:pl-10">Collection for Every Occasion</div>
            <p className="ahead text-xl md:text-2xl font-medium">
              "Our collection is as versatile as our customers. From sophisticated suits for corporate events to dazzling gowns for weddings, cute party outfits for kids, and comfortable casual wear, we truly mean it when we say 'All in All.' Whatever the occasion, we've got you covered!"
              </p>
          </div>
          <div className="4 my-10">
            <div className="atext1 pb-5 text-3xl md:text-4xl text-right md:pr-10">Craftsmanship and Quality</div>
            <p className="ahead text-xl md:text-2xl font-medium">
            "Every piece at All in All is crafted with love and care, ensuring that you receive only the finest quality. We source premium fabrics and partner with skilled designers to bring you stylish yet durable clothing that stands the test of time and trends."
              </p>
          </div>
          <div className="10 my-10">
            <div className="atext1 pb-5 text-3xl md:text-4xl text-left md:pl-10">Shopping Experience Like No Other</div>
            <p className="ahead text-xl md:text-2xl font-medium">
            "Shopping at All in All isn't just about clothes—it's about creating a memorable experience. Our friendly team is here to assist you in finding the perfect fit for every occasion. Visit our store to explore our collection in person or shop online for ultimate convenience. With us, you're always dressed to impress!"
              </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default About
