import React, { useState, useEffect, createContext } from "react";
import { BrowserRouter as Router, Route, Routes, useLocation, Navigate } from "react-router-dom";
import Header from "./components/Header";
import Landing2 from "./components/Landing2";  
import Home from "./components/Home";
import Collection from "./components/Collection";
import Displaycard from "./components/Displaycard";
import About from "./components/About";
import Wishlist from "./components/Wishlist";
import axios from "axios";
import Cart from "./components/Cart";

export const AppContext = createContext();

function App() {
  const [isRegistered, setIsRegistered] = useState(false);
  const [allproducts, setAllproducts] = useState([]);
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    const userStatus = localStorage.getItem('allinall');
    if (userStatus === 'true') {
      setIsRegistered(true);
    }

    const fetchProductsWithLikes = async () => {
      try {
        const response = await axios.get("http://localhost:8080/product/getall");
        const products = response.data;

        const email = localStorage.getItem('useremail');
        if (email) {
          const userResponse = await axios.get(`http://localhost:8080/user/getuserid/${email}`);
          const userId = userResponse.data;

          // Fetch isLiked for each product
          const enrichedProducts = await Promise.all(
            products.map(async (product) => {
              const isLikedResponse = await axios.get(`http://localhost:8080/wishlist/isLiked/${userId}/${product.id}`);
              return {
                ...product,
                isLiked: isLikedResponse.data, // Add isLiked dynamically
              };
            })
          );

          setAllproducts(enrichedProducts);
        } else {
          setAllproducts(products); // Fallback if user not logged in
        }
      } catch (error) {
        console.error("Failed to fetch products with likes:", error);
      }
    };

    fetchProductsWithLikes();
  }, []);

  const toggleLike = async (productId) => {
    try {
      const email = localStorage.getItem('useremail');
      if (!email) {
        console.error("User email not found in localStorage.");
        return;
      }
  
      const userResponse = await axios.get(`http://localhost:8080/user/getuserid/${email}`);
      const userId = userResponse.data;
  
      const productIndex = allproducts.findIndex((p) => p.id === productId);
      if (productIndex === -1) return;
  
      const isLiked = allproducts[productIndex].isLiked;
  
      // Optimistically update the UI to reflect the like/unlike action immediately
      const updatedProducts = [...allproducts];
      updatedProducts[productIndex].isLiked = !isLiked;
      setAllproducts(updatedProducts);
  
      // Now perform the backend operation
      if (isLiked) {
        // Unlike the product
        await axios.post(`http://localhost:8080/wishlist/unlike/${userId}/${productId}`);
        await axios.delete(`http://localhost:8080/wishlist/delwishlist/${userId}/${productId}`);
      } else {
        // Like the product
        await axios.post(`http://localhost:8080/wishlist/like/${userId}/${productId}`);
        await axios.post(`http://localhost:8080/wishlist/addwishlist/${userId}/${productId}`);
      }
  
      // Only update the backend after UI change is confirmed
      // If the backend update fails, don't revert the UI state here.
    } catch (error) {
      console.error("Error toggling like status:", error);
      // If error occurs, optionally alert the user or handle the error more gracefully.
      // We should **not revert the UI state** because it would cause flickering.
    }
  };

  return (
    <AppContext.Provider value={{ allproducts, cartCount, setCartCount, toggleLike }}>
      <Router>
        <MainContent isRegistered={isRegistered} setIsRegistered={setIsRegistered} />
      </Router>
    </AppContext.Provider>
  );
}

function MainContent({ isRegistered, setIsRegistered }) {
  const location = useLocation();

  return (
    <>
      {(location.pathname === "/home" || location.pathname === "/collection" || location.pathname === "/about" || location.pathname === "/cart" || location.pathname === "/wishlist") && <Header />}
      <div>
        <Routes>
          <Route path="/" element={isRegistered ? <Navigate to="/home" /> : <Landing2 />} />
          <Route path="/home" element={<Home />} />
          <Route path="/collection" element={<Collection />} />
          <Route path="/about" element={<About />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/landing" element={<Landing2 />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/displaycard/:id" element={<Displaycard />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
